# Website-botlist

> Change Log
> Some errors fixed.

> Premium system removed.

> Admin Panel modified..

> Bots, Bot info command added.

> A special url system has been added for certified bots.

> The "latest bots" section has been added to the Homepage.

> The code search channel was removed.

> Bot autorole has been added.

> Code request removed.

> The number of active users in the site has been added to the footer.

> Once the certificate is issued, automatic role assignment has been added.

> Elements that slow down the site have been removed.

> # Developers
> 👤 -Daddy.exe#3971

# Setup

Fill in the json files, link the required information and now it's ready.

# Extra Terms of use

- You have the permission to shoot and share videos, but you have to mention us, our server, in the video.
- You have the permission to share in writing, but you have to mention us, our server, in the article.
- - You are permitted to use and must include us in Footer(www/parts/foot.ejs) accordingly. If you don't do this and we discover you, I would like to say that this is not a good choice for you.
- You can't speak in a "we did it" way.
- You cannot sell it.

# Support Server [Click Here](https://discord.gg/gn24nq4RGp)
